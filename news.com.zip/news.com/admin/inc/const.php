<?php 
define("_DOMAIN_ADMIN",'http://'.$_SERVER['HTTP_HOST'].'/news.com/admin');
define("_DOMAIN",'http://'.$_SERVER['HTTP_HOST'].'/news.com');
?>