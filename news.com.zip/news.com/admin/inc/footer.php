
<?php mysqli_close($conn);?>	
</body>
</html>